# 6 Axis Force Torque Sensor Reader

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
python main.py [-p COM12] [-b 115200] [-n 6] [-f B_prime_custom.xlsx]
```
